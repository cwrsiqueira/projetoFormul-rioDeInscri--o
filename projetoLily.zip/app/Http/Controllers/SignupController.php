<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SignupController extends Controller
{
    public function index()
    {
        return view('signup');
    }

    public function direito_imagem()
    {
        return view('direito-de-imagem');
    }

    public function autorizacao_pais()
    {
        return view('autorizacao-pais');
    }

    public function pagamento()
    {
        return view('pagamento');
    }

    public function registrar(Request $request)
    {
        $data = $request->all();

        dd($data);
    }
}