<h1>Uso de Imagem</h1>
<?php /**PATH E:\projetos\projetoLily\resources\views/direito-de-imagem.blade.php ENDPATH**/ ?>