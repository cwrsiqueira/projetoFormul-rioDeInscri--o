<h1>Autorização dos Pais</h1>
<?php /**PATH E:\projetos\projetoLily\resources\views/autorizacao-pais.blade.php ENDPATH**/ ?>