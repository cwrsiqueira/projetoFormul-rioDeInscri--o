<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-3">
                <form action="<?php echo e(route('change_status', ['id' => $sub->id])); ?>" method="post">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm">
                            <div class="form-group">
                                <label for="status" class="form-control">STATUS:</label>
                                <select name="status" id="status" class="form-control">
                                    <option <?php if($sub->status == 'novo'): ?> selected <?php endif; ?> value="novo">Novo
                                    </option>
                                    <option <?php if($sub->status == 'confirmado'): ?> selected <?php endif; ?> value="confirmado">
                                        Confirmado</option>
                                    <option <?php if($sub->status == 'pendente'): ?> selected <?php endif; ?> value="pendente">Pendente
                                    </option>
                                    <option <?php if($sub->status == 'cancelado'): ?> selected <?php endif; ?> value="cancelado">
                                        Cancelado</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="form-group">
                                <label for="obs" class="form-control">OBSERVAÇÕES:</label>
                                <textarea name="obs" class="form-control"><?php echo e($sub->obs); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-outline-primary mb-3">Salvar Alterações</button>
                </form>
                <div class="row">
                    <div class="col-sm-3">
                        DATA CADASTRO: <input disabled type="text" class="form-control"
                            value="<?php echo e($sub->created_at); ?>">
                    </div>
                    <div class="col-sm-1">
                        ID: <input disabled type="text" class="form-control" value="<?php echo e($sub->id); ?>">
                    </div>
                    <div class="col-sm">
                        NOME: <input disabled type="text" class="form-control" value="<?php echo e($sub->uname); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-2">
                        IDADE: <input disabled type="text" class="form-control" value="<?php echo e($sub->age); ?>">
                    </div>
                    <div class="col-sm-2">
                        SEXO: <input disabled type="text" class="form-control" value="<?php echo e($sub->sexo); ?>">
                    </div>
                    <div class="col-sm">
                        NÚCLEO: <input disabled type="text" class="form-control" value="<?php echo e($sub->nucleo); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">
                        WHATSAPP: <input disabled type="text" class="form-control" value="<?php echo e($sub->phone1); ?>">
                    </div>
                    <div class="col-sm">
                        WHAT RESP.: <input disabled type="text" class="form-control" value="<?php echo e($sub->phone2); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">
                        SAÚDE:
                        <textarea class="form-control" disabled><?php echo e($sub->infosaude); ?></textarea>
                    </div>
                    <div class="col-sm">
                        NECESSIDADES:
                        <textarea class="form-control" disabled><?php echo e($sub->infonecessidades); ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">
                        CÓD. INSC.: <input disabled type="text" class="form-control" value="<?php echo e($sub->hash); ?>">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-sm">
                        <a href="<?php echo e($sub->autimgarquivo); ?>">Autorização de Imagem</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">
                        <a href="<?php echo e($sub->autpaisarquivo); ?>">Autorização do Responsável</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm">
                        <a href="<?php echo e($sub->comppagto); ?>">Comprovante de Pagamento</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH E:\projetos\projetoLily\resources\views/subscription.blade.php ENDPATH**/ ?>