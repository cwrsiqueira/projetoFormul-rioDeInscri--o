<h1>Pagamento</h1>
<?php /**PATH E:\projetos\projetoLily\resources\views/pagamento.blade.php ENDPATH**/ ?>